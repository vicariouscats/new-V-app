import React from 'react';
import { Text, ImageBackground, Dimensions } from 'react-native';
import { LinearGradient } from 'expo';

export default function ChallengeItem({ challenge }) {
  const screenWidth = Dimensions.get('window').width;
  return (
    <ImageBackground
      source={{ uri: challenge.picture }}
      style={{
        position: 'relative',
        width: screenWidth - 32,
        height: 200,
        marginTop: 16,
        borderRadius: 8,
        overflow: 'hidden'
      }}
    >
      <LinearGradient
        colors={['transparent', 'rgba(0, 0, 0, 0.5)']}
        style={{
          flex: 1,
          position: 'absolute',
          bottom: 0,
          padding: 8,
          width: '100%'
        }}
      >
        <Text
          style={{
            fontSize: 16,
            color: 'white'
          }}
        >
          {challenge.title}
        </Text>
      </LinearGradient>
    </ImageBackground>
  );
}

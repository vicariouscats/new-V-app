// import React, { Component } from "react";
// import {
//   Text,
//   View,
//   StyleSheet,
//   Button,
//   AsyncStorage,
//   TextInput,
//   TouchableOpacity,
//   KeyboardAvoidingView,
//   StatusBar
// } from "react-native";

// export default class SignInScreen extends Component {
//   signIn = async () => {
//     await AsyncStorage.setItem("userToken", "Edgar");

//     this.props.navigation.navigate("App");
//   };

//   render() {
//     return (
//       <View style={styles.container}>
//         <Button title="Complete Sign in" onPress={this.signIn} />
//       </View>
//     );
//   }
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//     alignItems: "center",
//     justifyContent: "center"
//   }
// });

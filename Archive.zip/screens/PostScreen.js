import React, { Component } from 'react';
import {
  View,
  StyleSheet,
  Text,
  TextInput,
  Image,
  TouchableOpacity
} from 'react-native';
import { ImagePicker } from 'expo';
import firebase from '../services/firebase';

export default class PostScreen extends Component {
  state = {
    loading: false,
    form: {
      title: '',
      content: '',
      pictureUrl: '',
      author: 'Tester'
    },
    picture: null
  };

  _pickImage = async () => {
    const { Permissions } = Expo;
    const result = await Permissions.askAsync(Permissions.CAMERA_ROLL);

    ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      base64: true
    })
      .then(result => {
        if (!result.cancelled) {
          console.log(result);
          this.setState({ picture: result });
        }
      })
      .catch(() => {});
  };

  handleSave = () => {
    // upload images
    var ref = firebase
      .storage()
      .ref()
      .child(`${Date.now()}.jpg`);

    ref.putString(this.state.picture.base64, 'base64').then(function(snapshot) {
      console.log('uploaded Url');
      snapshot.ref.getDownloadURL().then(console.log);
    });

    // update states
    // send to firebase
  };

  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <TouchableOpacity onPress={this._pickImage}>
          <Text>Select photo</Text>
        </TouchableOpacity>

        {this.state.picture && (
          <Image
            source={{
              uri: this.state.picture.uri
            }}
            style={{ width: 500, height: 200 }}
          />
        )}

        <TouchableOpacity onPress={this.handleSave}>
          <Text>Save</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
